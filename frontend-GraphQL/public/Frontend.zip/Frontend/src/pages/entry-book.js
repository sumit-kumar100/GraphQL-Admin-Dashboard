import AddEntry from '../frontend/entry-book/addEntry'
import ViewEntry from '../frontend/entry-book/viewEntry'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import requireAuthentication from '../utils/requireAuthentication'
import cookie from 'cookie'
import { wrapper } from '../redux/store'
import { toast } from "react-toastify"
import { Box, Container, Button, Accordion, AccordionDetails, AccordionSummary } from '@mui/material'
import { useState, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { AdminDashboardLayout } from '../components/dashboard'
import { actions } from '../frontend/entry-book/store'
import { createRecord, getData, updateRecord, deleteRecord } from '../frontend/entry-book/crud'
import createAxios from '../utils/createAxios'

const EntryBook = () => {

    const dispatch = useDispatch()

    const state = useSelector(state => state.entry)

    const [edit, setEdit] = useState(null)

    const [date, setDate] = useState(new Date())

    const [expanded, setExpanded] = useState(null)

    useEffect(() => {
        if (state?.message) {
            if (state.message === "Entry Created Successfully" || state.message === "Entry Updated Successfully") {
                toast.success(state.message)
            }
            else if (state.message === "Entry Deleted Successfully") {
                toast.warning(state.message)
            }
            else if (state.message === "Internal Servor Error") {
                toast.error(state.message)
            }
            else {
                toast.info("Something Went Wrong")
            }
            dispatch(actions.clearMessage())
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [state?.message])

    return (
        <AdminDashboardLayout>
            <Container maxWidth={false}>
                <Accordion sx={{ mb: 2 }} expanded={expanded} onChange={() => setExpanded(!expanded)}>
                    <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                    >
                        <Button
                            variant="text"
                            color="primary"
                            component="span"
                        >
                            Add Entry +
                        </Button>
                    </AccordionSummary>
                    <AccordionDetails>
                        <AddEntry
                            createRecord={createRecord}
                            updateRecord={updateRecord}
                            dispatch={dispatch}
                            edit={edit}
                            setEdit={setEdit}
                            date={date}
                            setDate={setDate}
                            setExpanded={setExpanded}
                            state={state}
                            actions={actions}
                        />
                    </AccordionDetails>
                </Accordion>
                <Box sx={{ p: 2, background: '#ffffff' }}>
                    <ViewEntry
                        state={state}
                        setEdit={setEdit}
                        deleteRecord={deleteRecord}
                        dispatch={dispatch}
                        getData={getData}
                        date={date}
                        setDate={setDate}
                        actions={actions}
                    />
                </Box>
            </Container>
        </AdminDashboardLayout>
    )
}

export default EntryBook

export const getServerSideProps = wrapper.getServerSideProps(
    (store) =>
        requireAuthentication(async (context) => {
            const { req, res } = context
            try {
                const axios = createAxios(req.cookies.accessToken)
                const entryData = await axios.post(`/api/entry/list/`, { conditions: { created_at: new Date() } })
                store.dispatch(actions.setInitialStore({
                    entryData: entryData?.data?.data
                }))
            } catch (e) {
                res.setHeader('Set-Cookie', cookie.serialize('accessToken', "", {
                    httpOnly: true,
                    expires: new Date(0),
                    sameSite: 'strict',
                    path: '/'
                }))
                return {
                    redirect: {
                        destination: '/login',
                        statusCode: 302
                    }
                }
            }
            return { props: {} }
        })
)