import ViewSales from '../frontend/sale-book'
import Query from '../utils/query'
import cookie from 'cookie'
import createAxios from '../utils/createAxios'
import requireAuthentication from '../utils/requireAuthentication'
import { wrapper } from '../redux/store'
import { Box, Container } from '@mui/material'
import { useSelector, useDispatch } from 'react-redux'
import { AdminDashboardLayout } from '../components/dashboard'
import { actions } from '../frontend/sale-book/store'
import { getData } from '../frontend/sale-book/crud'


const SalesBook = () => {

    const dispatch = useDispatch()

    const state = useSelector(state => state.sales)

    return (
        <AdminDashboardLayout>
            <Container maxWidth={false}>
                <Box sx={{ p: 2, background: '#ffffff' }}>
                    <ViewSales
                        state={state}
                        actions={actions}
                        dispatch={dispatch}
                        getData={getData}
                    />
                </Box>
            </Container>
        </AdminDashboardLayout>
    )
}

export default SalesBook


export const getServerSideProps = wrapper.getServerSideProps(
    (store) =>
        requireAuthentication(async (context) => {
            const { req, res } = context
            try {
                const axios = createAxios(req.cookies.accessToken)
                const customers = await axios.post('/api/customer/list/', {
                    conditions: { status: true },
                    fields: ['_id', 'name']
                })
                const sales = await axios.post(`/api/entry/list/`, Query.FetchSale())
                store.dispatch(actions.setInitialStore({
                    customers: customers?.data?.data,
                    saleData: sales?.data?.data
                }))
            } catch (e) {
                res.setHeader('Set-Cookie', cookie.serialize('accessToken', "", {
                    httpOnly: true,
                    expires: new Date(0),
                    sameSite: 'strict',
                    path: '/'
                }))
                return {
                    redirect: {
                        destination: '/login',
                        statusCode: 302
                    }
                }
            }

            return { props: {} }
        })
)
