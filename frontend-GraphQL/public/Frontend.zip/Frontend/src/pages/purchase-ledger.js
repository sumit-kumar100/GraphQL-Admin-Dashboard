import ViewPurchaseLedger from '../frontend/purchase-ledger'
import cookie from 'cookie'
import createAxios from '../utils/createAxios'
import requireAuthentication from '../utils/requireAuthentication'
import { wrapper } from '../redux/store'
import { Container, Box } from '@mui/material'
import { useSelector, useDispatch } from 'react-redux'
import { actions } from '../frontend/purchase-ledger/store'
import { getData } from '../frontend/purchase-ledger/crud'
import { AdminDashboardLayout } from '../components/dashboard';

const PurchaseLedger = (props) => {


    const dispatch = useDispatch()

    const state = useSelector(state => state.purchaseLedger)

    return (
        <AdminDashboardLayout>
            <Container maxWidth={false}>
                <Box sx={{ p: 2, background: '#ffffff' }}>
                    <ViewPurchaseLedger
                        state={state}
                        actions={actions}
                        dispatch={dispatch}
                        getData={getData}
                    />
                </Box>
            </Container>
        </AdminDashboardLayout>
    )
}

export default PurchaseLedger



export const getServerSideProps = wrapper.getServerSideProps(
    (store) =>
        requireAuthentication(async (context) => {
            const { req, res } = context
            try {
                const axios = createAxios(req.cookies.accessToken)
                const vendors = await axios.post('/api/vendor/list/', { conditions: { status: true }, fields: ['_id', 'name'] })
                store.dispatch(actions.setInitialStore({ vendors: vendors?.data?.data }))
            } catch (e) {
                res.setHeader('Set-Cookie', cookie.serialize('accessToken', "", {
                    httpOnly: true,
                    expires: new Date(0),
                    sameSite: 'strict',
                    path: '/'
                }))
                return {
                    redirect: {
                        destination: '/login',
                        statusCode: 302
                    }
                }
            }
            return { props: {} }
        })
)
