import IconButton from '@mui/material/IconButton'
import OutlinedInput from '@mui/material/OutlinedInput'
import InputLabel from '@mui/material/InputLabel'
import InputAdornment from '@mui/material/InputAdornment'
import FormControl from '@mui/material/FormControl'
import Visibility from '@mui/icons-material/Visibility'
import VisibilityOff from '@mui/icons-material/VisibilityOff'
import Image from 'next/image'
import * as yup from 'yup'
import axios from 'axios'
import decode from 'jwt-decode'
import dynamic from 'next/dynamic'
import { useRouter } from 'next/router'
import { yupResolver } from '@hookform/resolvers/yup'
import { useForm, Controller } from "react-hook-form"
import { useState } from 'react'
import { Box, Typography, TextField, Button, Container, FormHelperText, Alert } from '@mui/material'


const defaultValues = {
    mobile: "",
    password: ""
}

const Login = () => {
    const validateSchema = {
        mobile: yup.string().required('Mobile no. is required'),
        password: yup.string().required('Password is required').matches(/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/, "Must Contain 8 Characters, One UpperCase & LowerCase, One Number and One Special Character [@$!%*#?&]")
    }

    const {
        control,
        handleSubmit,
        reset,
        formState: { errors }
    } = useForm({ defaultValues, resolver: yupResolver(yup.object().shape(validateSchema)) })

    const router = useRouter()

    const [showPassword, setShowPassword] = useState(false)

    const [loginError, setLoginError] = useState(null)

    const [showSubscription, setShowSubscription] = useState(false)

    const Subscription = dynamic(() => import('../components/subscription'))

    const onSubmit = async (data, e) => {
        e?.preventDefault()
        const response = await axios.post('/api/auth/login-user', data)
        if (response?.data?.status) {
            setLoginError(null)
            const userData = decode(response.data.data.token)
            reset({ ...defaultValues })
            if (!userData.status) {
                setShowSubscription(true)
                return
            }
            router.replace('/entry-book')
        }
        setLoginError(response?.data?.error)
    }

    return (
        <form onSubmit={handleSubmit(onSubmit)} noValidate={true}>
            <Container>
                <Box sx={{ marginX: { sm: 0, md: 14 }, display: 'flex', boxShadow: '0px 10px 34px -15px rgb(0 0 0 / 24%)', height: '85vh', mt: 4, borderRadius: 1 }}>
                    <Box sx={{ width: '45%', display: { xs: 'none', md: 'block' } }}>
                        <Image
                            src='/login.svg'
                            alt="Login Image"
                            width={500}
                            height={550}
                        />
                    </Box>
                    <Box sx={{ width: { xs: '100%', md: '55%' }, padding: { xs: 2, md: 7 } }}>
                        {!showSubscription ? (<>
                            <Typography variant="h5" sx={{ letterSpacing: 1 }} textAlign="center">LOGIN</Typography>
                            <Controller
                                render={({ field }) => (
                                    <TextField
                                        sx={{ mb: 3, mt: 3 }}
                                        error={errors.mobile ? true : false}
                                        helperText={errors.mobile ? errors.mobile.message : ""}
                                        fullWidth
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">+91</InputAdornment>
                                        }}
                                        label='Enter Mobile'
                                        {...field}
                                    />
                                )}
                                name='mobile'
                                control={control}
                            />
                            <Controller
                                render={({ field }) => (
                                    <FormControl sx={{ mb: 3 }} variant="outlined" fullWidth>
                                        <InputLabel htmlFor="outlined-adornment-password">Password</InputLabel>
                                        <OutlinedInput
                                            type={showPassword ? 'text' : 'password'}
                                            error={errors.password ? true : false}
                                            endAdornment={
                                                <InputAdornment position="end">
                                                    <IconButton
                                                        onClick={() => setShowPassword(!showPassword)}
                                                        edge="end"
                                                    >
                                                        {showPassword ? <VisibilityOff /> : <Visibility />}
                                                    </IconButton>
                                                </InputAdornment>
                                            }
                                            label="Password"
                                            {...field}
                                        />
                                        {errors.password ? (
                                            <FormHelperText error>
                                                {errors.password.message}
                                            </FormHelperText>
                                        ) : null}
                                    </FormControl>

                                )}
                                name='password'
                                control={control}
                            />
                            {loginError ?
                                <FormHelperText error sx={{ marginBottom: 2, marginLeft: 2 }}>
                                    {loginError}
                                </FormHelperText>
                                : null}
                            <Button type='submit' color='primary' variant="contained" fullWidth>Continue to Login</Button>
                            <Box
                                onClick={() => router.replace('/register')}
                                textAlign="right"
                                my={3}
                                color="#2065D1"
                                fontSize={14}
                                fontWeight="600"
                                sx={{
                                    cursor: 'pointer'
                                }}>
                                Don&apos;t have account ? Sign Up
                            </Box>
                        </>) : <Subscription registrationSuccess={false} />}
                    </Box>
                </Box>
            </Container>
        </form>
    )
}

export default Login


export async function getServerSideProps(context) {
    const { req, res } = context
    const accessToken = req.cookies.accessToken
    if (accessToken) {
        const response = await axios.post('/api/auth/verify-user', { accessToken })
        if (response?.data?.status) {
            const account = decode(accessToken)
            if (account.status === true) {
                return {
                    redirect: {
                        destination: '/entry-book',
                        statusCode: 302
                    }
                }
            }
        }
    }
    return { props: {} }
}