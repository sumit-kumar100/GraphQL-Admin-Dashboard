import ViewCash from '../frontend/cash-book'
import Query from '../utils/query'
import Axios from 'axios'
import createAxios from '../utils/createAxios'
import cookie from 'cookie'
import requireAuthentication from '../utils/requireAuthentication'
import { getData } from '../frontend/cash-book/crud'
import { wrapper } from '../redux/store'
import { actions } from '../frontend/cash-book/store'
import { Container, Box } from '@mui/material'
import { useSelector, useDispatch } from 'react-redux'
import { AdminDashboardLayout } from '../components/dashboard'

const CashBook = (props) => {

    const dispatch = useDispatch()

    const state = useSelector(state => state.cash)

    return (
        <AdminDashboardLayout>
            <Container maxWidth={false}>
                <Box sx={{ p: 2, background: '#ffffff' }}>
                    <ViewCash
                        state={state}
                        dispatch={dispatch}
                        getData={getData}
                    />
                </Box>
            </Container>
        </AdminDashboardLayout>
    )
}

export default CashBook



export const getServerSideProps = wrapper.getServerSideProps(
    (store) =>
        requireAuthentication(async (context) => {
            const { req, res } = context
            try {
                const axios = createAxios(req.cookies.accessToken)
                const { cashReceive, cashPaid, cashSale, cashPurchase, cashByUser } = { ...Query.FetchCash() }
                const [cashReceiveData, cashPaidData, cashSaleData, cashPurchaseData, userCashData] = await Axios.all([
                    axios.post('/api/customer/list/', cashReceive),
                    axios.post('/api/vendor/list/', cashPaid),
                    axios.post('/api/entry/list/', cashSale),
                    axios.post('/api/entry/list/', cashPurchase),
                    axios.post('/api/user/list/', cashByUser),
                ])
                store.dispatch(actions.setInitialStore({
                    cashReceiveData: cashReceiveData?.data?.data,
                    cashPaidData: cashPaidData?.data?.data,
                    cashSaleData: cashSaleData?.data?.data,
                    cashPurchaseData: cashPurchaseData?.data?.data,
                    userCashData: userCashData?.data?.data
                }))
            }
            catch (e) {
                res.setHeader('Set-Cookie', cookie.serialize('accessToken', "", {
                    httpOnly: true,
                    expires: new Date(0),
                    sameSite: 'strict',
                    path: '/'
                }))
                return {
                    redirect: {
                        destination: '/login',
                        statusCode: 302
                    }
                }
            }
            return { props: {} }
        })
)
