import connectDB from '../../../backend/database'
import Models from '../../../backend/models'
import utils from '../../../backend/utils'
import withProtect from '../../../backend/middlewares/withProtect'

const handler = async (req, res) => {
    try {
        let model = Models[req?.query?.model?.toUpperCase()]
        if (!model) {
            return utils.sendResponse({ res, status: false, statusCode: 500, error: utils.message.INVALID_MODEL })
        }
        const fields = req.body.fields ? req.body.fields : {}
        const conditions = req.body.conditions ? req.body.conditions : {}
        if (req?.body?.aggregate) {
            const data = await model.aggregate(!req?.body?.matchWithId ? [{ $match: { auth: req?.user?._id } }, ...conditions] : [{ $match: { _id: req?.user?._id } }, ...conditions], fields)
            return utils.sendResponse({ res, data, message: null })
        }
        const data = req.body.findOne ? await model.findOne({ auth: req?.user?._id, ...conditions }, fields) : await model.find({ auth: req?.user?._id, ...conditions }, fields)
        return utils.sendResponse({ res, data, message: null })
    }
    catch (error) {
        return utils.sendResponse({ res, status: false, statusCode: 500, error: utils.raiseException(error.message) })
    }
}

export default connectDB(withProtect(handler))