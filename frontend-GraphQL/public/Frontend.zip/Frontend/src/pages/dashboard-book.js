import requireAuthentication from '../utils/requireAuthentication'
import { AdminDashboardLayout } from '../components/dashboard'

const Dashboard = (props) => {
    return (
        <AdminDashboardLayout>
            Dashboard
        </AdminDashboardLayout>
    )
}

export default Dashboard


export const getServerSideProps = requireAuthentication((context) => {
    return { props: {} }
})
