import CheckSum from 'paytmchecksum'

let paytmCheckSum = ""

let paytmParams = {}

const received_data = JSON.parse(`{}`)

for (let key in received_data) {
    if (key === 'CHECKSUMHASH') {
        paytmCheckSum = received_data[key]
    }
    else {
        paytmParams[key] = received_data[key]
    }
}

let isValidCheckSum = CheckSum.verifySignature(paytmParams, "", paytmCheckSum)

isValidCheckSum ? console.log("CHECKSUM MATCHED") : console.log("CHECKSUM NOT MATCHED")