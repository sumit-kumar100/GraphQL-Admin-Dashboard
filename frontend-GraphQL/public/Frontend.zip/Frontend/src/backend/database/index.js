import mongoose from 'mongoose'

const MONGODB_USERNAME = 'Sumit1196'

const MONGODB_PASSWORD = 'Sumit1196'

const MONGODB_DATABASE = 'business'

const mongoAtlasUri = `mongodb+srv://${MONGODB_USERNAME}:${MONGODB_PASSWORD}@cluster0.zuifn.mongodb.net/${MONGODB_DATABASE}?retryWrites=true&w=majority`

const connectDB = handler => async (req, res) => {
    await mongoose.connect(mongoAtlasUri)
    return handler(req, res)
}

export default connectDB