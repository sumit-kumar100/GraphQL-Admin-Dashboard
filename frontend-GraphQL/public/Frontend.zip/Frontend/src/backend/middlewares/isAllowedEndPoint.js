import Models from '../models'
import utils from '../utils'

const isAllowedEndPoint = async (req) => {
    try {
        const token = req?.headers?.authorization.split(" ")[1] || null

        if (!token) {
            return false
        }

        const decoded = utils.auth.verifyToken(token)

        const user = await Models.USER.findById(decoded._id)

        if (!user) {
            return false
        }

        return user
    }
    catch (e) {
        return false
    }
}

export default isAllowedEndPoint