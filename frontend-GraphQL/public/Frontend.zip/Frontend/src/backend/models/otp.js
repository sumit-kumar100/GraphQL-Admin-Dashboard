import mongoose from 'mongoose'
import DateOnly from 'mongoose-dateonly'

const schema = new mongoose.Schema({
    code: {
        type: Number,
        required: true
    },
    created_at: {
        type: DateOnly(mongoose),
        required: true,
        default: Date.now
    },
    updated_at: {
        type: DateOnly(mongoose),  
        required: true,
        default: Date.now
    }
})

const otp = mongoose.models.otp || mongoose.model("otp", schema)

export default otp
