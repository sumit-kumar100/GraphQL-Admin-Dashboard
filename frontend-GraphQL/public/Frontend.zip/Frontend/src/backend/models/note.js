import mongoose from 'mongoose'
import DateOnly from 'mongoose-dateonly'

const schema = new mongoose.Schema({
    auth: {
        type: mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'user'
    },
    text: {
        type: String,
        required: true,
        trim: true
    },
    options: [
        {
            type: Object,
            required: false,
            default: {}
        }
    ],
    status: {
        type: Boolean,
        required: true,
        default: true
    },
    created_at: {
        type: DateOnly(mongoose),
        required: true,
        default: Date.now
    },
    updated_at: {
        type: DateOnly(mongoose),
        required: true,
        default: Date.now
    }
})

const note = mongoose.models.note || mongoose.model("note", schema)

export default note
