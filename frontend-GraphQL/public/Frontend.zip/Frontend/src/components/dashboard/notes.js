import axios from 'axios'
import DataTable from '../datatable'
import DateOnly from 'dateonly'
import Menu from '../menu'
import CloseIcon from '@mui/icons-material/Close'
import { deleteAlert } from '../alert'
import { fDate } from '../../utils/formatTime'
import { toast } from 'react-toastify'
import { Box, Typography, Tab, Button, IconButton } from '@mui/material'
import { useState, useEffect } from 'react'
import { useQuill } from 'react-quilljs'
import 'quill/dist/quill.snow.css'


export default function Notes({ setShow }) {

    const { quill, quillRef } = useQuill()

    const [notes, setNotes] = useState([])

    const [edit, setEdit] = useState(null)

    const fetchNotes = async () => {
        const response = await axios.post('/api/note/list')
        if (response?.data?.status) {
            setNotes(response.data.data)
        }
    }

    const handleDelete = async _id => {
        try {
            const confirm = await deleteAlert()
            if (confirm) {
                const response = await axios.delete('/api/note/', { data: { _id } })
                if (response?.data?.status) {
                    toast.warning(response.data.message)
                    fetchNotes()
                    return
                }
            }
            return false
        } catch (e) {
            toast.error(e?.response?.data?.error)
        }
    }

    const handleSubmit = async () => {
        if (quill.getText().length > 1) {
            let response
            if (!edit) {
                response = await axios.post('/api/note',
                    {
                        text: quill.getText(),
                        options: quill.getContents().ops,
                        created_at: new Date(),
                        updated_at: new Date()
                    }
                )
            } else {
                response = await axios.put('/api/note',
                    {
                        _id: edit?._id,
                        text: quill.getText(),
                        options: quill.getContents().ops,
                        updated_at: new Date()
                    }
                )
                setEdit(null)
            }
            if (response?.data?.status) {
                fetchNotes()
                toast.success(!edit ? "NOTE CREATED SUCCESSFULLY" : "NOTE UPDATED SUCCESSFULLY")
                quill.setContents([])
            }
        }
    }

    useEffect(() => {
        fetchNotes()
    }, [])


    const columns = [
        {
            name: 'SNO.',
            cell: (row, index) => (
                <Box width="120px">
                    {`${index + 1}`}
                </Box>
            )
        },
        {
            name: 'Note',
            cell: row => (
                <Box width="120px">
                    {`${row.text}`}
                </Box>
            )
        },
        {
            name: 'Created At',
            cell: row => (
                <Box width="120px">
                    {`${fDate(new DateOnly(row.created_at).toDate())}`}
                </Box>
            )
        },
        {
            name: 'Updated At',
            cell: row => (
                <Box width="120px">
                    {`${fDate(new DateOnly(row.updated_at).toDate())}`}
                </Box>
            )
        },
        {
            name: "Edit",
            center: true,
            cell: row => (
                <Menu
                    onEdit={() => {
                        quill.setContents(row?.options)
                        setEdit(row)
                    }}
                    onDelete={() => handleDelete(row?._id)}
                />
            )
        }
    ]
    return (
        <Box sx={{ width: '100%' }}>
            <Typography textAlign="center">
                <Tab label="All Notes" />
            </Typography>
            <IconButton onClick={() => setShow(false)} sx={{ position: 'absolute', top: 5, right: 18, cursor: 'pointer' }} >
                <CloseIcon />
            </IconButton>
            <Box ref={quillRef} />

            <Button variant='outlined' size="small" sx={{ my: 2 }} onClick={handleSubmit}>
                {!edit ? "Add Note" : "Update Note"}
            </Button>

            <Button variant='outlined' size="small" sx={{ my: 2, mx: 2 }} onClick={() => {
                quill.setContents([])
                setEdit(null)
            }}>
                Clear Note
            </Button>

            <DataTable
                columns={columns}
                data={notes}
            />
        </Box>
    )
}
