import DateOnly from 'dateonly'

class Query {
    static FetchPurchase(startDate = new Date(), endDate = new Date(), vendor = null) {
        return vendor ? {
            aggregate: true,
            conditions: [
                {
                    $match: {
                        'vendor': vendor,
                        'mode': 'CREDIT',
                        'created_at': {
                            $gte: new DateOnly(startDate),
                            $lte: new DateOnly(endDate)
                        }
                    }
                },
                {
                    $project: {
                        '_id': 1,
                        'quantity': 1,
                        'details': 1,
                        'vendor': 1,
                        'price': 1,
                        'total': 1,
                        'charges': 1,
                        'created_at': 1
                    }
                },
                {
                    $group: {
                        _id: {
                            'date': '$created_at',
                            'name': '$vendor'
                        },
                        data: {
                            $push: '$$ROOT'
                        }
                    }
                },
                {
                    $group: {
                        _id: '$_id.date',
                        names: {
                            $push: '$$ROOT'
                        }
                    }
                }
            ]
        } : {
            aggregate: true,
            conditions: [
                {
                    $match: {
                        'mode': 'CREDIT',
                        'created_at': {
                            $gte: new DateOnly(startDate),
                            $lte: new DateOnly(endDate)
                        }
                    }
                },
                {
                    $project: {
                        '_id': 1,
                        'quantity': 1,
                        'details': 1,
                        'vendor': 1,
                        'price': 1,
                        'total': 1,
                        'charges': 1,
                        'created_at': 1
                    }
                },
                {
                    $group: {
                        _id: {
                            'date': '$created_at',
                            'name': '$vendor'
                        },
                        data: {
                            $push: '$$ROOT'
                        }
                    }
                },
                {
                    $group: {
                        _id: '$_id.date',
                        names: {
                            $push: '$$ROOT'
                        }
                    }
                }
            ]
        }
    }


    static FetchSale(startDate = new Date, endDate = new Date, customer = null) {
        return customer ? {
            aggregate: true,
            conditions: [
                { $unwind: "$sales" },
                {
                    $match: {
                        'sales.customer': customer,
                        'sales.mode': 'CREDIT',
                        'sales.created_at': {
                            $gte: new DateOnly(startDate),
                            $lte: new DateOnly(endDate)
                        }
                    }
                },
                { $replaceRoot: { newRoot: "$sales" } },
                {
                    $group: {
                        _id: {
                            'date': '$created_at',
                            'name': '$customer'
                        },
                        data: {
                            $push: '$$ROOT'
                        }
                    }
                },
                {
                    $group: {
                        _id: '$_id.date',
                        names: {
                            $push: '$$ROOT'
                        }
                    }
                }
            ]
        } : {
            aggregate: true,
            conditions: [
                { $unwind: "$sales" },
                {
                    $match: {
                        'sales.mode': 'CREDIT',
                        'sales.created_at': {
                            $gte: new DateOnly(startDate),
                            $lte: new DateOnly(endDate)
                        }
                    }
                },
                { $replaceRoot: { newRoot: "$sales" } },
                {
                    $group: {
                        _id: {
                            'date': '$created_at',
                            'name': '$customer'
                        },
                        data: {
                            $push: '$$ROOT'
                        }
                    }
                },
                {
                    $group: {
                        _id: '$_id.date',
                        names: {
                            $push: '$$ROOT'
                        }
                    }
                }
            ]
        }
    }



    static FetchPurchaseLedger(startDate = new Date(), endDate = new Date(), vendor = null) {
        return {
            entry: {
                aggregate: true,
                conditions: [
                    {
                        $match: {
                            'vendor': vendor,
                            'mode': 'CREDIT',
                            'created_at': {
                                $gte: new DateOnly(startDate),
                                $lte: new DateOnly(endDate)
                            }
                        }
                    },
                    {
                        $project: {
                            '_id': 1,
                            'quantity': 1,
                            'details': 1,
                            'vendor': 1,
                            'price': 1,
                            'total': 1,
                            'charges': 1,
                            'created_at': 1
                        }
                    },
                    {
                        $group: {
                            _id: {
                                'date': '$created_at',
                                'name': '$vendor'
                            },
                            data: {
                                $push: '$$ROOT'
                            }
                        }
                    },
                    {
                        $group: {
                            _id: '$_id.date',
                            names: {
                                $push: '$$ROOT'
                            }
                        }
                    }
                ]
            },
            vendor: {
                aggregate: true,
                conditions: [
                    {
                        $match: {
                            "name": vendor
                        }
                    },
                    {
                        $project: {
                            _id: 1,
                            credit: 1,
                            name: 1,
                            debit: {
                                $filter: {
                                    input: "$debit",
                                    as: "debits",
                                    cond: {
                                        $and: [
                                            { $gte: ["$$debits.date", new DateOnly(startDate)] },
                                            { $lte: ["$$debits.date", new DateOnly(endDate)] }
                                        ]
                                    }
                                }
                            }
                        }
                    }
                ]
            }
        }
    }


    static FetchSaleLedger(startDate = new Date, endDate = new Date, customer = null) {
        return {
            entry: {
                aggregate: true,
                conditions: [
                    { $unwind: "$sales" },
                    {
                        $match: {
                            'sales.customer': customer,
                            'sales.mode': 'CREDIT',
                            'sales.created_at': {
                                $gte: new DateOnly(startDate),
                                $lte: new DateOnly(endDate)
                            }
                        }
                    },
                    { $replaceRoot: { newRoot: "$sales" } },
                    {
                        $group: {
                            _id: {
                                'date': '$created_at',
                                'name': '$customer'
                            },
                            data: {
                                $push: '$$ROOT'
                            }
                        }
                    },
                    {
                        $group: {
                            _id: '$_id.date',
                            names: {
                                $push: '$$ROOT'
                            }
                        }
                    }
                ]
            },
            customer: {
                aggregate: true,
                conditions: [
                    {
                        $match: {
                            "name": customer
                        }
                    },
                    {
                        $project: {
                            _id: 1,
                            debit: 1,
                            name: 1,
                            type: 1,
                            credit: {
                                $filter: {
                                    input: "$credit",
                                    as: "credits",
                                    cond: {
                                        $and: [
                                            {
                                                $gte: ["$$credits.date", new DateOnly(startDate)]
                                            },
                                            {
                                                $lte: ["$$credits.date", new DateOnly(endDate)]
                                            }
                                        ]
                                    }
                                }
                            }
                        }
                    }
                ]
            }
        }
    }


    static FetchCash(startDate = new Date(), endDate = new Date()) {
        return {
            cashReceive: {
                aggregate: true,
                conditions: [
                    { $project: { 'credit': 1, 'name': 1 } },
                    { $unwind: "$credit" },
                    {
                        $match: {
                            'credit.date': {
                                $gte: new DateOnly(startDate),
                                $lte: new DateOnly(endDate)
                            }
                        }
                    }
                ]
            },
            cashPaid: {
                aggregate: true,
                conditions: [
                    { $project: { 'debit': 1, 'name': 1 } },
                    { $unwind: "$debit" },
                    {
                        $match: {
                            'debit.date': {
                                $gte: new DateOnly(startDate),
                                $lte: new DateOnly(endDate)
                            }
                        }
                    }
                ]
            },
            cashSale: {
                aggregate: true,
                conditions: [
                    { $project: { 'sales': 1 } },
                    { $unwind: "$sales" },
                    {
                        $match: {
                            'sales.mode': { $ne: 'CREDIT' },
                            'sales.created_at': {
                                $gte: new DateOnly(startDate),
                                $lte: new DateOnly(endDate)
                            }
                        }
                    }
                ]
            },
            cashPurchase: {
                conditions: {
                    'mode': { $ne: 'CREDIT' },
                    'created_at': {
                        $gte: new DateOnly(startDate),
                        $lte: new DateOnly(endDate)
                    }
                },
                fields: [
                    '_id', 'quantity', 'details', 'vendor', 'price', 'total', 'mode', 'charges', 'created_at'
                ]
            },
            cashByUser: {
                aggregate: true,
                matchWithId: true,
                conditions: [
                    {
                        $project: {
                            _id: 1,
                            credits: {
                                $filter: {
                                    input: "$credits",
                                    as: "creditsData",
                                    cond: {
                                        $and: [
                                            {
                                                $gte: ["$$creditsData.date", new DateOnly(startDate)]
                                            },
                                            {
                                                $lte: ["$$creditsData.date", new DateOnly(endDate)]
                                            }
                                        ]
                                    }
                                }
                            },
                            debits: {
                                $filter: {
                                    input: "$debits",
                                    as: "debitsData",
                                    cond: {
                                        $and: [
                                            {
                                                $gte: ["$$debitsData.date", new DateOnly(startDate)]
                                            },
                                            {
                                                $lte: ["$$debitsData.date", new DateOnly(endDate)]
                                            }
                                        ]
                                    }
                                }
                            }
                        }
                    }
                ]
            }
        }
    }

}

export default Query