import HighLight from 'react-highlighter'
import DateOnly from 'dateonly'
import Card from './card'
import { handleCreditCash } from './crud'
import { Table, TableBody, TableCell, TableHead, TableRow, Box } from '@mui/material'
import { fDate } from '../../utils/formatTime'

const CreditTable = ({ state, search, startDate, endDate }) => {
    return (
        <div style={{ background: '#ffffff' }}>
            <Table size="small">
                <TableHead sx={{ height: '45px' }}>
                    <TableRow >
                        <TableCell align='center'>
                            <Box width="120px">
                                Date
                            </Box>
                        </TableCell>
                        <TableCell align='center'>
                            <Box width="120px">
                                Particulars
                            </Box>
                        </TableCell>
                        <TableCell align='center'>
                            <Box width="120px">
                                Amount
                            </Box>
                        </TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {state?.cashPurchaseData?.map((purchase, index) => (
                        <TableRow key={index}>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <HighLight search={search}>
                                        {`${fDate(new DateOnly(purchase?.created_at).toDate())}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <HighLight search={search}>
                                        {`By ${purchase?.vendor} ${purchase?.mode === 'BANK' ? "(Bank)" : ""}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                            <TableCell align='center'>
                                <Box width="120px" color='red'>
                                    <HighLight search={search}>
                                        {`₹ ${purchase?.total}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                        </TableRow>
                    ))}

                    {state?.cashPaidData?.map((row, index) => (
                        <TableRow key={index}>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <HighLight search={search}>
                                        {`${fDate(new DateOnly(row?.debit?.date).toDate())}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <HighLight search={search}>
                                        {`By ${row?.name} ${row?.debit?.mode === 'BANK' ? "(Bank)" : ""}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                            <TableCell align='center'>
                                <Box width="120px" color='green'>
                                    <HighLight search={search}>
                                        {`₹ ${row?.debit?.amount}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                        </TableRow>
                    ))}
                    {state?.userCashData[0]?.credits?.map((row, index) => (
                        <TableRow key={index}>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <HighLight search={search}>
                                        {`${fDate(new DateOnly(row?.date).toDate())}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <HighLight search={search}>
                                        {`By ${row?.information} ${row?.mode === 'BANK' ? "(Bank)" : ""}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <Card
                                        search={search}
                                        handleCashSubmit={(data, row) => handleCreditCash(data, row, startDate, endDate)}
                                        row={row}
                                        credit={true}
                                    />
                                </Box>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    )
}

export default CreditTable
