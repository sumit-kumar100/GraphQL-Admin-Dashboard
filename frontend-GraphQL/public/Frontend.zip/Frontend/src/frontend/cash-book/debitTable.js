import HighLight from 'react-highlighter'
import DateOnly from 'dateonly'
import Card from './card'
import { handleDebitCash } from './crud'
import { Table, TableBody, TableCell, TableHead, TableRow, Box } from '@mui/material'
import { fDate } from '../../utils/formatTime'

const DebitTable = ({ state, search, startDate, endDate }) => {
    return (
        <div style={{ background: '#ffffff' }}>
            <Table size="small">
                <TableHead sx={{ height: '45px' }}>
                    <TableRow >
                        <TableCell align='center'>
                            <Box width="120px">
                                Date
                            </Box>
                        </TableCell>
                        <TableCell align='center'>
                            <Box width="120px">
                                Particulars
                            </Box>
                        </TableCell>
                        <TableCell align='center'>
                            <Box width="120px">
                                Amount
                            </Box>
                        </TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {state?.cashSaleData?.map(({ sales }, index) => (
                        <TableRow key={index}>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <HighLight search={search}>
                                        {`${fDate(new DateOnly(sales?.created_at).toDate())}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <HighLight search={search}>
                                        {`To ${sales?.customer} ${sales?.mode === 'BANK' ? "(Bank)" : ""}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                            <TableCell align='center'>
                                <Box width="120px" color="red">
                                    <HighLight search={search}>
                                        {`₹ ${sales?.total}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                        </TableRow>
                    ))}
                    {state?.cashReceiveData?.map(({ credit, name }, index) => (
                        <TableRow key={index}>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <HighLight search={search}>
                                        {`${fDate(new DateOnly(credit?.date).toDate())}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <HighLight search={search}>
                                        {`To ${name} ${credit?.mode === 'BANK' ? "(Bank)" : ""}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                            <TableCell align='center'>
                                <Box width="120px" color="green">
                                    <HighLight search={search}>
                                        {`₹ ${credit?.amount}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                        </TableRow>
                    ))}
                    {state?.userCashData[0]?.debits?.map((row, index) => (
                        <TableRow key={index}>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <HighLight search={search}>
                                        {`${fDate(new DateOnly(row?.date).toDate())}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                            <TableCell align='center'>
                                <Box width="120px">
                                    <HighLight search={search}>
                                        {`To ${row?.information} ${row?.mode === 'BANK' ? "(Bank)" : ""}`}
                                    </HighLight>
                                </Box>
                            </TableCell>
                            <TableCell align='center'>
                                <Box width="120px" >
                                    <Card
                                        search={search}
                                        handleCashSubmit={(data, row) => handleDebitCash(data, row, startDate, endDate)}
                                        row={row}
                                        debit={true}
                                    />
                                </Box>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </div>
    )
}

export default DebitTable
