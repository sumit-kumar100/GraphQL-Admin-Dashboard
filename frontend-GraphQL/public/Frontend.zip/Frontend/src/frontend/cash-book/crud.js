import axios from 'axios'
import Query from '../../utils/query'
import { actions } from './store'
import { wrapper } from '../../redux/store'


export const getData = wrapper.getServerSideProps(
    (store) =>
        async (params) => {
            const { cashReceive, cashPaid, cashSale, cashPurchase, cashByUser, fetchUserCashOnly } = { ...params }

            if (fetchUserCashOnly) {
                const response = await axios.post('/api/user/list/', cashByUser)
                store.dispatch(actions.updateUserCashData(response?.data?.data))
                return
            }

            const [cashReceiveData, cashPaidData, cashSaleData, cashPurchaseData, userCashData] = await axios.all([
                axios.post('/api/customer/list/', cashReceive),
                axios.post('/api/vendor/list/', cashPaid),
                axios.post('/api/entry/list/', cashSale),
                axios.post('/api/entry/list/', cashPurchase),
                axios.post('/api/user/list/', cashByUser),
            ])

            store.dispatch(actions.setInitialStore({
                cashReceiveData: cashReceiveData?.data?.data,
                cashPaidData: cashPaidData?.data?.data,
                cashSaleData: cashSaleData?.data?.data,
                cashPurchaseData: cashPurchaseData?.data?.data,
                userCashData: userCashData?.data?.data
            }))
        }
)


export const handleDebitCash = async (data, row, startDate, endDate) => {
    const response = row ? await axios.put('/api/auth-user/update-debit-user-cash', { ...data, _id: row?._id }) : await axios.put('/api/auth-user/create-debit-user-cash', { data })
    getData({ ...Query.FetchCash(startDate, endDate), fetchUserCashOnly: true })
    return response
}

export const handleCreditCash = async (data, row, startDate, endDate) => {
    const response = row ? await axios.put('/api/auth-user/update-credit-user-cash', { ...data, _id: row?._id }) : await axios.put('/api/auth-user/create-credit-user-cash', { data })
    getData({ ...Query.FetchCash(startDate, endDate), fetchUserCashOnly: true })
    return response
}

