import axios from 'axios'
import HighLight from 'react-highlighter'
import Charges from '../../components/charges'
import DateOnly from 'dateonly'
import { Table, TableBody, TableCell, TableHead, TableRow, Box } from '@mui/material'
import { fDate } from '../../utils/formatTime'



const Credits = ({ search, credits, openingBalance, state, dispatch, actions, startDate, endDate }) => {

  const handleCharges = async charges => {
    const response = await axios.put(`/api/vendor/`, { _id: state.vendorLedgerData._id, credit: charges, updateName: false })
    if (response?.data?.status) {
      const params = {
        aggregate: true,
        conditions: [
          {
            $match: {
              "name": state.vendorLedgerData.name,
            }
          },
          {
            $project: {
              _id: 1,
              credit: 1,
              name: 1,
              type: 1,
              debit: {
                $filter: {
                  input: "$debit",
                  as: "debits",
                  cond: {
                    $and: [
                      { $gte: ["$$debits.date", new DateOnly(startDate)] },
                      { $lte: ["$$debits.date", new DateOnly(endDate)] }
                    ]
                  }
                }
              }
            }
          }
        ]
      }
      const resp = await axios.post("/api/vendor/list", params)
      await dispatch(actions.setVendorLedgerData(resp?.data?.data[0]))
    }
    return true
  }

  return (
    <div style={{ background: '#ffffff' }}>
      <Table size="small">
        <TableHead sx={{ height: '45px' }}>
          <TableRow >
            <TableCell align='center'>
              <Box width="120px">
                Date
              </Box>
            </TableCell>
            <TableCell align='center'>
              <Box width="120px">
                Particulars
              </Box>
            </TableCell>
            <TableCell align='center'>
              <Box width="120px">
                Amount
              </Box>
            </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          <TableRow>
            <TableCell align='center'><Box width="120px" /></TableCell>
            <TableCell align='center'>
              <Box width="120px">
                <HighLight search={search}>
                  {"Previous balances & losses"}
                </HighLight>
              </Box>
            </TableCell>
            <TableCell align='center'>
              <Box width="120px">
                <Charges
                  search={search}
                  additionalCost={openingBalance}
                  handleCharges={charges => handleCharges(charges)}
                />
              </Box>
            </TableCell>
          </TableRow>
          {credits?.map((row, index) => (
            <TableRow key={index}>
              <TableCell align='center'>
                <Box width="120px">
                  <HighLight search={search}>
                    {`${fDate(new DateOnly(row?._id).toDate())}`}
                  </HighLight>
                </Box>
              </TableCell>
              <TableCell align='center'>
                <Box width="120px">
                  <HighLight search={search}>
                    By Purchases
                  </HighLight>
                </Box>
              </TableCell>
              <TableCell align='center'>
                <Box width="120px">
                  <HighLight search={search}>
                    {`₹ ${row?.names?.reduce((prev, curr) => prev + curr?.data.reduce(((sum, item) => sum + item.total + item.charges), 0), 0)}`}
                  </HighLight>
                </Box>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

export default Credits
