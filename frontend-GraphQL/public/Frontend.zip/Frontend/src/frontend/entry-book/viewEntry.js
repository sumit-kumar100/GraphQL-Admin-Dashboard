import DataTable from '../../components/datatable'
import DateOnly from 'dateonly'
import Menu from '../../components/menu'
import HighLight from 'react-highlighter'
import Filters from './filters'
import { useState } from 'react'
import { Box, Typography } from '@mui/material'
import { fDate, formatDate2 } from '../../utils/formatTime'
import { deleteAlert } from '../../components/alert'


const ViewEntry = ({ state, setEdit, deleteRecord, dispatch, getData, date, setDate, actions }) => {

    const [search, setSearch] = useState("")

    const handleEdit = row => {
        setEdit(row)
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        })
    }

    const handleDelete = async row => {
        const confirm = await deleteAlert()
        if (confirm) {
            await deleteRecord(row._id, date)
            dispatch(actions.updateMessage("Entry Deleted Successfully"))
        }
        return
    }

    const columns = [
        {
            name: 'Date',
            cell: row => (
                <Box width="120px">
                    <HighLight search={search}>
                        {`${fDate(new DateOnly(row.created_at).toDate())}`}
                    </HighLight>
                </Box>
            )
        },
        {
            name: 'Details',
            cell: row => (
                <Box width="280px">
                    <Box my={1}>
                        <HighLight search={search}>
                            {`${row.quantity} ${row.details} ${row.vendor} ${"x"} ${row.price} ${row.mode === 'CASH' ? '(cash)' : row.mode === 'BANK' ? '(bank)' : ''}`}
                        </HighLight>
                    </Box>
                    {row?.sales?.map((item, index) => (
                        <Box key={index} marginLeft={new DateOnly(row.created_at).valueOf() !== item.created_at ? 0 : 5}>
                            <Box my={0.5}>
                                <HighLight search={search}>
                                    {new DateOnly(row.created_at).valueOf() !== item.created_at ? (
                                        <span style={{ paddingRight: 20 }}>
                                            {`(${formatDate2(new DateOnly(item.created_at).toDate())})*`}
                                        </span>
                                    ) : null}
                                    {`${item.quantity} ${item.details} ${item.customer} ${"x"} ${item.price} ${item.mode === 'CASH' ? '(cash)' : item.mode === 'BANK' ? '(bank)' : ''}`}
                                </HighLight>
                            </Box>
                        </Box>
                    ))}
                </Box>
            )
        },
        {
            name: 'Purchases(₹)',
            cell: row => (
                <Box width="100px">
                    <Box my={1}>
                        <HighLight search={search}>
                            {`₹ ${row.total}`}
                        </HighLight>
                    </Box>
                    <Box marginLeft={5}>
                        {row?.sales?.map((item, index) => (
                            <Box my={0.5} key={index}>
                                <span style={{ visibility: 'hidden' }}>{"null"}</span>
                            </Box>
                        ))}
                    </Box>
                </Box>
            )
        },
        {
            name: 'Sales(₹)',
            cell: row => (
                <Box width="100px">
                    <Box my={1}>
                        <span style={{ visibility: 'hidden' }}>{"null"}</span>
                    </Box>
                    <Box>
                        {row?.sales?.map((item, index) => (
                            <Box my={0.5} key={index}>
                                <HighLight search={search}>
                                    {`₹ ${item.total}`}
                                </HighLight>
                            </Box>
                        ))}
                    </Box>
                </Box>
            )
        },
        {
            name: 'Profit(₹)',
            cell: row => (
                <Box widht="100px">
                    <HighLight search={search}>
                        {`₹ ${(row?.sales?.reduce((total, item) => total + item.total, 0)) - (row?.total)}`}
                    </HighLight>
                </Box>
            )

        },
        {
            name: "Edit",
            center: true,
            cell: row => (
                <Menu
                    onEdit={() => handleEdit(row)}
                    onDelete={() => handleDelete(row)}
                />
            )
        }
    ]

    return (
        <Box>
            <Typography fontWeight="400" fontSize={{ xs: 16, md: 21 }} textAlign="center" my={2}>
                {`Entries for, ${fDate(new DateOnly(state?.entryData[0]?.created_at).toDate() || new Date())}`}
            </Typography>

            <Filters
                getData={getData}
                search={search}
                setSearch={setSearch}
                date={date}
                setDate={setDate}
            />

            <DataTable
                columns={columns}
                data={state?.entryData}
            />
        </Box>
    )
}

export default ViewEntry