import DataTable from '../../components/datatable'
import DateOnly from 'dateonly'
import Filters from '../../components/filters'
import CloseIcon from '@mui/icons-material/Close'
import axios from 'axios'
import { useState } from 'react'
import { Box, IconButton, Typography } from '@mui/material'
import { fDate } from '../../utils/formatTime'



const ReceiptInformation = ({ paymentInfoModal, setPaymentInfoModal, customersList }) => {

    const [ReceiptInfoDetail, setReceiptInfoDetail] = useState([])

    const [customer, setCustomer] = useState(null)

    const [startDate, setStartDate] = useState(new Date())

    const [endDate, setEndDate] = useState(new Date())

    const Columns = [
        {
            name: 'S.No.',
            cell: (row, index) => (
                <Box>
                    {`${index + 1}`}
                </Box>
            )
        },
        {
            name: 'Date',
            cell: (row, index) => (
                <Box sx={{ minWidth: '80px' }}>
                    {`${fDate(new DateOnly(row?.credit?.date).toDate())}`}
                </Box>
            )
        },
        {
            name: 'Amount(₹)',
            cell: (row, index) => (
                <Box>
                    {`₹ ${row?.credit?.amount}`}
                </Box>
            )
        },
    ]

    const getReceiptInfo = async () => {
        const params = {
            aggregate: true,
            conditions: [
                { $match: { name: customer } },
                { $project: { 'credit': 1 } },
                { $unwind: "$credit" },
                {
                    $match: {
                        'credit.date': {
                            $gte: new DateOnly(startDate),
                            $lte: new DateOnly(endDate)
                        }
                    }
                }
            ]
        }
        const response = await axios.post('/api/customer/list/', params)
        if (response?.data?.status) {
            setReceiptInfoDetail(response?.data?.data || [])
        }
    }

    return (
        <>
            <IconButton onClick={() => setPaymentInfoModal(false)} sx={{ position: 'absolute', top: 15, right: 10, cursor: 'pointer' }} >
                <CloseIcon />
            </IconButton>
            <Typography my={3} fontWeight="bold" textAlign="center">
                Receipt Information
            </Typography>
            {paymentInfoModal ? (
                <Filters
                    device="desktop"
                    isLedgerFilter={true}
                    nameTag="Account"
                    buttonTag="Collect"
                    name={customer}
                    setName={setCustomer}
                    startDate={startDate}
                    setStartDate={setStartDate}
                    endDate={endDate}
                    setEndDate={setEndDate}
                    names={customersList.filter(name => name !== 'Balance Account' && name !== 'Loss Account')}
                    applyFilter={getReceiptInfo}
                />
            ) : null}
            <br />
            {ReceiptInfoDetail.length > 0 ? (
                <DataTable
                    size="medium"
                    columns={Columns}
                    data={ReceiptInfoDetail || []}
                />
            ) : (
                <Box textAlign="center" >
                    No Records To Display
                </Box>
            )}
        </>
    )
}


export default ReceiptInformation