import axios from 'axios'
import { actions } from './store'
import { wrapper } from '../../redux/store'



export const getData = wrapper.getServerSideProps(
    (store) =>
        async (params) => {
            const { entry, customer } = { ...params }
            const saleLedgerData = await axios.post("/api/entry/list/", entry)
            const customerLedgerData = await axios.post("/api/customer/list", customer)
            store.dispatch(actions.setData({
                customerLedgerData: customerLedgerData?.data?.data[0],
                saleLedgerData: saleLedgerData?.data?.data
            }))
        }
)