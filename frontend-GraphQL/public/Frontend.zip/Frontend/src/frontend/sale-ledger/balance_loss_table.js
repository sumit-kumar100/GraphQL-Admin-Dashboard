import HighLight from 'react-highlighter'
import DateOnly from 'dateonly'
import { Table, TableBody, TableCell, TableHead, TableRow, Box, TableContainer, Paper } from '@mui/material'
import { fDate } from '../../utils/formatTime'

const Account = ({ search, debits }) => (
    <TableContainer component={Paper} sx={{ marginTop: 5 }}>
        <Table>
            <TableHead sx={{ height: '45px' }}>
                <TableRow >
                    <TableCell align='center'>
                        Date
                    </TableCell>
                    <TableCell align='center'>
                        Details
                    </TableCell>
                    <TableCell align='center'>
                        Amount
                    </TableCell>
                </TableRow>
            </TableHead>
            <TableBody>
                {debits?.map((row, index) => (
                    <TableRow key={index}>
                        <TableCell align='center'>
                            <HighLight search={search}>
                                {`${fDate(new DateOnly(row?._id).toDate())}`}
                            </HighLight>
                        </TableCell>
                        <TableCell align='center'>
                            <HighLight search={search}>
                                {row?.names[0]?.data?.map((balance) => (
                                    <Box>
                                        {`${balance.quantity} ${balance.details} ${balance.customer} ${"x"} ${balance.price}`}
                                    </Box>
                                ))}
                            </HighLight>
                        </TableCell>
                        <TableCell align='center'>
                            <HighLight search={search}>
                                {`₹ ${row?.names?.reduce((prev, curr) => prev + curr?.data.reduce(((sum, item) => sum + item.total + item.charges), 0), 0)}`}
                            </HighLight>
                        </TableCell>
                    </TableRow>
                ))}
            </TableBody>
        </Table>
    </TableContainer>
)

export default Account
